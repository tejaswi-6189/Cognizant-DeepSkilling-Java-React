package com.cognizant.countryxml;

import com.cognizant.countryxml.model.Country;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CountryXmlApplication {

	public static void main(String[] args) {

		ApplicationContext context =
				new ClassPathXmlApplicationContext("country.xml");

		Country country = (Country) context.getBean("country");

		System.out.println("Country Details:");
		System.out.println(country);
	}
}