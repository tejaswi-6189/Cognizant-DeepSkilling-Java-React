package com.cognizant.countryxml;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CountryXmlApplicationTests {

	@Test
	void contextLoads() {
	}

}
