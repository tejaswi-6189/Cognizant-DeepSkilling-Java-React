package com.cognizant.getcountry.controller;

import com.cognizant.getcountry.model.Country;
import org.springframework.web.bind.annotation.*;

@RestController
public class CountryController {

    @GetMapping("/country/{code}")
    public Country getCountry(@PathVariable String code){
        if(code.equalsIgnoreCase("IN")){
            return new Country("IN","India");
        }
        return new Country(code.toUpperCase(),"Country Not Found");
    }
}
