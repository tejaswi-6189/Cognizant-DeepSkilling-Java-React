package com.cognizant.countryservice.controller;
import com.cognizant.countryservice.model.Country;
import org.springframework.web.bind.annotation.*;
@RestController
public class CountryController{
 @GetMapping("/country")
 public Country getCountry(){
   return new Country("IN","India");
 }
}
